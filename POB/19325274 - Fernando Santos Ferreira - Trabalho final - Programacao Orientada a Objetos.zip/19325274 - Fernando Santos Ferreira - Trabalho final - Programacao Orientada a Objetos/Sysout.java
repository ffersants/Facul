public class Sysout{
    public static void consoleLog(String txt){
        System.out.println(txt);
    }
    public static void consoleLog(int txt){
        System.out.println(txt);
    }
    public static void consoleLog(double txt){
        System.out.println(txt);
    }
}